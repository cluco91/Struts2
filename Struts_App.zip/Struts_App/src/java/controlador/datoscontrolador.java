/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import com.opensymphony.xwork2.ModelDriven;
import dao.daocliente;
import dao.implement;
import entidad.Datos;
import java.util.ArrayList;

public class datoscontrolador implements ModelDriven<Datos> {
   Datos datos=new Datos();//obejto datods q es el q vamos a manejar
   ArrayList<Datos> listaclientes=new ArrayList();
   daocliente clidao;
   String msg="";
   
   
   //Constructor
   public datoscontrolador()
   {
       clidao=new implement();
   }
   
   
   
    public Datos getModel() {//retorna el objeto de relacion de los campos definidos en jsp
     return datos;
    }
    
    
    public String agrego (){
    clidao.agrego(datos);
    listaclientes=clidao.listar();
     return "exito";  
     
    }
    
    
    
     public String borrar(){
     clidao.borrar(datos);
     listaclientes=clidao.listar();
     return "exito";  
     }
    
    
    public String listar (){
     listaclientes=clidao.listar();
     return "exito";   
    }
    
    
    /*
     * mete los getters de datos , lista y msg
     * y set de cliente solamente
     * 
     * */
  
    public Datos getDatos() {
        return datos;
    }

    public void setDatos(Datos datos) {
        this.datos = datos;
    }


    public ArrayList<Datos> getListaclientes() {
        return listaclientes;
    }

    public String getMsg() {
        return msg;
    }

}

