/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entidad.Datos;
import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author user
 */
public class implement implements daocliente {

    
Transaction transaction=null;
Session session;

    public boolean agrego(Datos datos) {
       try
       { 
           session = HibernateUtil.getSessionFactory().getCurrentSession();
           transaction=session.beginTransaction();
           //registrar o actualizar
           session.saveOrUpdate(datos);//guarda info
           transaction.commit();//cambios a la base :D
           return true;
       }
       catch(Exception e)
       {
           if(transaction!=null)
               transaction.rollback();
           
           return false;
       }
    }
   
    
    
     public boolean borrar(Datos datos) {
       try
       { 
           session = HibernateUtil.getSessionFactory().getCurrentSession();
           transaction=session.beginTransaction();
           session.delete(datos);//guarda info
           transaction.commit();//cambios a la base :D
           return true;
       }
       catch(Exception e)
       {
           if(transaction!=null)
               transaction.rollback();
           
           return false;
       }
    }
    
    
    
    

    public ArrayList<Datos> listar() {
        try
        {
           Session session; 
           Transaction transaction;
           session = HibernateUtil.getSessionFactory().getCurrentSession();
           transaction=session.beginTransaction();
           return (ArrayList<Datos>)session.createQuery("from Datos").list();
        }
        catch(Exception e)
        {
            return null;
        }
    }
    
}
