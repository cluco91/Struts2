/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entidad.Datos;
import java.util.ArrayList;

public interface daocliente {
    
    public boolean agrego(Datos datos);
    public boolean borrar(Datos datos);
    public ArrayList<Datos> listar();
    
}
